﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioSettings : MonoBehaviour
{
    public static float volumeMusic = 0.5f;
    public static float volumeSoundEffect = 0.5f;
}
